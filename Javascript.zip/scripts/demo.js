			function demoExternalAlert(){
				alert("This Is An External Alert");
			}
			function demoExternalConfirm(){
				if(confirm("Are You Fine Gaurav..?")){
					alert("Ok..Thank You..");
				}
				else{
				    alert("Let Me Know If Any Needed...");
				}
			}
			function demoExternalPrompt(){
				var FName=prompt("Enter Your First Name..");
				var LName=prompt("Enter Your Last Name..");
				alert(FName+" "+LName);
			}